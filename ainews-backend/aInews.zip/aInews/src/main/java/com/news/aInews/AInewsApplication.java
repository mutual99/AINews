package com.news.aInews;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class AInewsApplication {

	public static void main(String[] args) {
		SpringApplication.run(AInewsApplication.class, args);
	}

}
